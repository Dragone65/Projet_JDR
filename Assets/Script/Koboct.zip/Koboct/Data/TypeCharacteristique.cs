﻿namespace Koboct.Data
{
    public enum TypeCharacteristique
    {
        Aucune=0,
        Force=1,
        Dexterite= 2,
        Constitution=3,
        Intelligence=4,
        Sagesse=5,
        Charisme=6,
    }
}